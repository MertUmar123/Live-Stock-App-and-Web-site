<?php
// Marketstack API key. It lives on the server, so website visitors never see it.
define('MARKETSTACK_KEY', 'PASTE_YOUR_KEY_HERE');
define('MARKETSTACK_URL', 'https://api.marketstack.com/v2');

// End-of-day prices only change once a day, so we keep each answer for 12 hours.
// This protects the free plan limit (100 requests per month).
define('CACHE_SECONDS', 12 * 60 * 60);
