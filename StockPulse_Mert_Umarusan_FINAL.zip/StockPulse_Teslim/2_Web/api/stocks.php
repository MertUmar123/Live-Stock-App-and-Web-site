<?php
/*
 * StockPulse - stocks.php
 * Small backend between the website and the Marketstack API.
 *
 *   api/stocks.php?action=latest&symbols=AAPL,MSFT   -> latest end-of-day price per stock
 *   api/stocks.php?action=history&symbol=AAPL        -> daily closing prices of the last year
 *
 * Why PHP here?
 *  1) The API key stays secret on the server (it is not in the JavaScript).
 *  2) Answers are cached in files, so we do not waste the 100 free requests per month.
 */

require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

function send_error($message, $status = 400) {
    http_response_code($status);
    echo json_encode(['error' => $message]);
    exit;
}

// Only allow normal ticker symbols like "AAPL" or "SAP.XETRA"
function clean_symbols($raw) {
    $symbols = array_filter(array_map('trim', explode(',', $raw)));
    if (count($symbols) === 0 || count($symbols) > 20) {
        send_error('Please send between 1 and 20 symbols.');
    }
    foreach ($symbols as $s) {
        if (!preg_match('/^[A-Za-z0-9.\-]{1,20}$/', $s)) {
            send_error('Invalid symbol: ' . $s);
        }
    }
    return $symbols;
}

// Download a URL, but reuse a saved copy if it is younger than CACHE_SECONDS
function get_with_cache($url, $cacheName) {
    $dir = __DIR__ . '/cache';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        file_put_contents($dir . '/.htaccess', "Require all denied\n"); // nobody can open the cache in a browser
    }
    $file = $dir . '/' . md5($cacheName) . '.json';

    if (file_exists($file) && time() - filemtime($file) < CACHE_SECONDS) {
        return json_decode(file_get_contents($file), true);
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $body = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $json = $body ? json_decode($body, true) : null;
    if ($status === 200 && isset($json['data'])) {
        file_put_contents($file, $body);
        return $json;
    }

    // The API failed: an old saved answer is better than nothing
    if (file_exists($file)) {
        return json_decode(file_get_contents($file), true);
    }
    send_error('Stock API is not reachable right now.', 502);
}

$action = $_GET['action'] ?? 'latest';

if ($action === 'latest') {
    $symbols = clean_symbols($_GET['symbols'] ?? '');
    $list = implode(',', $symbols);
    $url = MARKETSTACK_URL . '/eod/latest?access_key=' . MARKETSTACK_KEY . '&symbols=' . urlencode($list);
    $json = get_with_cache($url, 'latest_' . $list);

    $result = [];
    foreach ($json['data'] as $row) {
        $result[] = [
            'symbol' => $row['symbol'],
            'open'   => $row['open'],
            'high'   => $row['high'],
            'low'    => $row['low'],
            'close'  => $row['close'],
            'volume' => $row['volume'],
            'date'   => substr($row['date'], 0, 10),
            'currency' => $row['price_currency'] ?? null,
            'exchange' => $row['exchange'] ?? null,
        ];
    }
    echo json_encode($result);

} elseif ($action === 'history') {
    $symbol = clean_symbols($_GET['symbol'] ?? '')[0];
    $from = date('Y-m-d', strtotime('-1 year'));
    $url = MARKETSTACK_URL . '/eod?access_key=' . MARKETSTACK_KEY
         . '&symbols=' . urlencode($symbol) . '&date_from=' . $from . '&limit=300';
    $json = get_with_cache($url, 'history_' . $symbol);

    $result = [];
    foreach ($json['data'] as $row) {
        $result[] = ['date' => substr($row['date'], 0, 10), 'close' => $row['close']];
    }
    // Oldest day first, so the chart goes from left (past) to right (today)
    usort($result, fn($a, $b) => strcmp($a['date'], $b['date']));
    echo json_encode($result);

} else {
    send_error('Unknown action.');
}
