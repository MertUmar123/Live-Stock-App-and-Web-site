/* ============================================
   StockPulse - app.js
   Shared UI helpers used across all pages.
   ============================================ */

const CURRENCY_SYMBOLS = { USD: "$", EUR: "€", GBP: "£", JPY: "¥", TRY: "₺" };

let APP_STATE = {
  country: DB.get("spx_country", "Germany"),
  currency: DB.get("spx_currency", "EUR")
};

/* Highlight the active nav link based on current file name */
function initNavActive() {
  const page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".spx-navbar .nav-link").forEach(link => {
    if (link.getAttribute("href") === page) link.classList.add("active");
  });
}

/* Wire up every currency <select> on the page */
function initCurrencySelect(onChange) {
  document.querySelectorAll("[data-currency-select]").forEach(el => {
    el.value = APP_STATE.currency;
    el.addEventListener("change", async (e) => {
      APP_STATE.currency = e.target.value;
      DB.set("spx_currency", APP_STATE.currency);
      DB.set("spx_currency_manual", true); // the user chose it, so location won't overwrite it
      if (onChange) await onChange(APP_STATE.currency);
    });
  });
}

/* Detect the country, update the "location" pill, then let the page load its data */
async function initLocationPill(onCountryResolved) {
  const pillEls = document.querySelectorAll("[data-loc-pill]");
  pillEls.forEach(p => p.innerHTML = `<span class="dot-live"></span> Detecting location…`);

  const country = await detectCountry();
  APP_STATE.country = country;
  DB.set("spx_country", country);

  const market = COUNTRY_MARKETS[country];
  pillEls.forEach(p => {
    p.innerHTML = `<span class="dot-live"></span> ${market.flag} ${country} · ${market.index}`;
  });

  if (!DB.get("spx_currency_manual", false)) {
    APP_STATE.currency = market.currency;
    DB.set("spx_currency", market.currency);
    document.querySelectorAll("[data-currency-select]").forEach(el => el.value = market.currency);
  }

  if (onCountryResolved) await onCountryResolved(country);
}

function fmtMoney(value, currency) {
  const symbol = CURRENCY_SYMBOLS[currency] || "";
  return `${symbol}${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtVolume(v) {
  if (!v) return "-";
  if (v >= 1e9) return (v / 1e9).toFixed(2) + "B";
  if (v >= 1e6) return (v / 1e6).toFixed(2) + "M";
  if (v >= 1e3) return (v / 1e3).toFixed(1) + "K";
  return String(v);
}

/* Link to Google News for any search words */
function newsUrl(query) {
  return `https://news.google.com/search?q=${encodeURIComponent(query)}`;
}

/* Show a warning box when the API was offline and sample numbers are shown */
function showDataNotice(isSample) {
  document.querySelectorAll("[data-notice]").forEach(el => {
    el.innerHTML = isSample
      ? `<div class="data-notice">⚠ Stock API is not reachable right now - showing sample data.</div>`
      : "";
  });
}

/* Exchange rates from every stock's own currency to the chosen currency.
   Example: { USD: 0.92, EUR: 1 } when the user wants EUR */
async function ratesFor(quotes) {
  const rates = {};
  for (const q of quotes) {
    if (!(q.currency in rates)) rates[q.currency] = await getExchangeRate(q.currency, APP_STATE.currency);
  }
  return rates;
}

function chipHTML(q, currency, rate) {
  const up = q.changePct >= 0;
  return `
    <div class="ticker-chip ${up ? "is-up" : "is-down"}" data-symbol="${q.symbol}">
      <div>
        <div class="sym">${q.symbol}</div>
        <div class="name">${q.name}</div>
      </div>
      <div class="text-end">
        <div class="price">${fmtMoney(q.price * rate, currency)}</div>
        <span class="chg-pill ${up ? "up" : "down"}">${up ? "▲" : "▼"} ${Math.abs(q.changePct).toFixed(2)}%</span>
      </div>
    </div>`;
}

/* Standard boot sequence every page calls */
async function bootPage({ onCountryResolved, onCurrencyChange } = {}) {
  initNavActive();
  initCurrencySelect(onCurrencyChange);
  await initLocationPill(onCountryResolved);
}
