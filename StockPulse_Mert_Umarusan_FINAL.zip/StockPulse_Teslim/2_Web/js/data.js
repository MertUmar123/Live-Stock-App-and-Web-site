/* ============================================
   StockPulse - data.js
   Handles: stock data (from our PHP backend),
   currency conversion, geolocation -> country.
   ============================================ */

/* ---------------------------------------------------------
   1) API
   The browser never talks to Marketstack directly.
   It asks our own PHP file (api/stocks.php), which keeps
   the API key secret and caches the answers.
--------------------------------------------------------- */
const API_URL = "api/stocks.php";

/* ---------------------------------------------------------
   2) COUNTRY -> MARKET DATA
   "code" is the ISO country code we get from geolocation.
--------------------------------------------------------- */
const COUNTRY_MARKETS = {
  "Germany":        { code: "DE", flag: "🇩🇪", index: "DAX",        currency: "EUR" },
  "United States":  { code: "US", flag: "🇺🇸", index: "S&P 500",    currency: "USD" },
  "United Kingdom": { code: "GB", flag: "🇬🇧", index: "FTSE 100",   currency: "GBP" },
  "France":         { code: "FR", flag: "🇫🇷", index: "CAC 40",     currency: "EUR" },
  "Japan":          { code: "JP", flag: "🇯🇵", index: "Nikkei 225", currency: "JPY" },
  "Turkey":         { code: "TR", flag: "🇹🇷", index: "BIST 100",   currency: "TRY" }
};

/* "api"  = the symbol Marketstack expects.
   "cur"  = the currency the API returns the price in.
   The free Marketstack plan does not include the German, UK, Japanese or
   Turkish exchanges, so for those companies we use their US listing
   (NYSE / Nasdaq, priced in USD). The site converts the price to the
   user's currency. Paris (XPAR) is included in the free plan.
   "base" = a typical price, only used for sample data if the API is offline. */
const STOCKS_BY_COUNTRY = {
  "Germany": [
    { symbol: "SAP",  api: "SAP",  cur: "USD", name: "SAP SE",                 base: 224.29 },
    { symbol: "DB",   api: "DB",   cur: "USD", name: "Deutsche Bank",          base: 30.10 },
    { symbol: "BNTX", api: "BNTX", cur: "USD", name: "BioNTech SE",            base: 105.00 },
    { symbol: "FMS",  api: "FMS",  cur: "USD", name: "Fresenius Medical Care", base: 24.50 }
  ],
  "United States": [
    { symbol: "AAPL", api: "AAPL", cur: "USD", name: "Apple Inc.",      base: 343.46 },
    { symbol: "TSLA", api: "TSLA", cur: "USD", name: "Tesla Inc.",      base: 239.43 },
    { symbol: "NFLX", api: "NFLX", cur: "USD", name: "Netflix Inc.",    base: 855.86 },
    { symbol: "MSFT", api: "MSFT", cur: "USD", name: "Microsoft Corp.", base: 421.10 },
    { symbol: "NVDA", api: "NVDA", cur: "USD", name: "NVIDIA Corp.",    base: 132.75 }
  ],
  "United Kingdom": [
    { symbol: "HSBC", api: "HSBC", cur: "USD", name: "HSBC Holdings", base: 94.57 },
    { symbol: "BP",   api: "BP",   cur: "USD", name: "BP plc",        base: 50.21 },
    { symbol: "UL",   api: "UL",   cur: "USD", name: "Unilever",      base: 60.00 },
    { symbol: "AZN",  api: "AZN",  cur: "USD", name: "AstraZeneca",   base: 75.00 }
  ],
  "France": [
    { symbol: "MC",  api: "MC.XPAR", cur: "EUR", name: "LVMH",          base: 397.00 },
    { symbol: "TTE", api: "TTE",     cur: "USD", name: "TotalEnergies", base: 62.10 },
    { symbol: "SNY", api: "SNY",     cur: "USD", name: "Sanofi",        base: 50.00 }
  ],
  "Japan": [
    { symbol: "TM",   api: "TM",   cur: "USD", name: "Toyota Motor",          base: 194.61 },
    { symbol: "SONY", api: "SONY", cur: "USD", name: "Sony Group",            base: 24.88 },
    { symbol: "MUFG", api: "MUFG", cur: "USD", name: "Mitsubishi UFJ Financial", base: 14.00 }
  ],
  "Turkey": [
    { symbol: "TKC", api: "TKC", cur: "USD", name: "Turkcell", base: 4.93 }
  ]
};

// Exchange codes (MIC) from the API -> readable names
const EXCHANGE_NAMES = { XNYS: "NYSE", XNAS: "Nasdaq", XPAR: "Euronext Paris" };

function findStock(country, symbol) {
  return (STOCKS_BY_COUNTRY[country] || []).find(s => s.symbol === symbol);
}

/* ---------------------------------------------------------
   3) SAMPLE DATA (only if the API cannot be reached)
   Every sample value is marked with isSample: true and the
   page shows a warning, so it is never mixed up with real data.
--------------------------------------------------------- */
function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function sampleQuote(s) {
  const changePct = (seededRandom(s.symbol.charCodeAt(0) + s.symbol.length) - 0.5) * 8;
  const price = s.base * (1 + changePct / 100);
  return {
    symbol: s.symbol, name: s.name, currency: s.cur, exchange: "-",
    price: Number(price.toFixed(2)), open: s.base, high: Math.max(price, s.base), low: Math.min(price, s.base),
    volume: 0, date: "-",
    change: Number((price - s.base).toFixed(2)),
    changePct: Number(changePct.toFixed(2)),
    isSample: true
  };
}

function sampleHistory(s) {
  const points = [];
  let value = s.base;
  const day = new Date();
  for (let i = 0; i < 252; i++) {
    value = Math.max(value + (seededRandom(s.symbol.charCodeAt(0) * (i + 1)) - 0.48) * s.base * 0.015, s.base * 0.5);
    points.unshift({ date: day.toISOString().slice(0, 10), close: Number(value.toFixed(2)) });
    day.setDate(day.getDate() - 1);
  }
  return points;
}

/* ---------------------------------------------------------
   4) PUBLIC DATA FUNCTIONS (used by the pages)
--------------------------------------------------------- */
// Remember answers while the page is open, so the same request is not sent twice
const requestMemory = {};
async function getJSON(url) {
  if (!requestMemory[url]) {
    requestMemory[url] = fetch(url).then(res => {
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    });
  }
  try {
    return await requestMemory[url];
  } catch (err) {
    delete requestMemory[url];
    throw err;
  }
}

// Marketstack may answer "SAP.XETRA" or just "SAP", so we accept both
function rowMatches(row, stock) {
  return row.symbol === stock.api || row.symbol === stock.symbol || row.symbol.split(".")[0] === stock.symbol;
}

async function fetchQuotes(country) {
  const list = STOCKS_BY_COUNTRY[country] || STOCKS_BY_COUNTRY["Germany"];
  try {
    const symbols = list.map(s => s.api).join(",");
    const rows = await getJSON(`${API_URL}?action=latest&symbols=${encodeURIComponent(symbols)}`);
    const quotes = [];
    for (const s of list) {
      const d = rows.find(r => rowMatches(r, s));
      if (!d) continue; // the API has no data for this stock
      quotes.push({
        symbol: s.symbol, name: s.name,
        currency: d.currency || s.cur,
        exchange: EXCHANGE_NAMES[d.exchange] || d.exchange || "-",
        price: d.close, open: d.open, high: d.high, low: d.low,
        volume: d.volume, date: d.date,
        change: Number((d.close - d.open).toFixed(2)),
        changePct: Number((((d.close - d.open) / d.open) * 100).toFixed(2)),
        isSample: false
      });
    }
    if (quotes.length > 0) return quotes;
    throw new Error("No stocks returned");
  } catch (err) {
    console.warn("Stock API failed, showing sample data:", err);
    return list.map(sampleQuote);
  }
}

// One request gives the whole last year; the ranges are cut from it
async function fetchHistory(stock) {
  try {
    const rows = await getJSON(`${API_URL}?action=history&symbol=${encodeURIComponent(stock.api)}`);
    if (rows.length > 0) return { points: rows, isSample: false };
    throw new Error("Empty history");
  } catch (err) {
    console.warn("History API failed, showing sample data:", err);
    return { points: sampleHistory(stock), isSample: true };
  }
}

// Trading days per range. The free plan has no intraday data,
// so "1D" shows the last 5 trading days instead of hours.
const RANGE_DAYS = { "1D": 5, "1M": 22, "3M": 66, "1Y": 252 };

function cutRange(points, range) {
  return points.slice(-(RANGE_DAYS[range] || 22));
}

/* ---------------------------------------------------------
   5) CURRENCY CONVERSION (Frankfurter - free, no API key)
--------------------------------------------------------- */
const rateMemory = {};
async function getExchangeRate(from, to) {
  if (from === to) return 1;
  const key = from + to;
  if (rateMemory[key]) return rateMemory[key];
  try {
    const res = await fetch(`https://api.frankfurter.dev/v1/latest?base=${from}&symbols=${to}`);
    const json = await res.json();
    rateMemory[key] = json.rates[to];
    return rateMemory[key];
  } catch (err) {
    console.warn("Currency API failed, using rate 1:1", err);
    return 1;
  }
}

/* ---------------------------------------------------------
   6) GEOLOCATION -> COUNTRY
   Browser Geolocation API + OpenStreetMap Nominatim.
   We compare the ISO country code ("DE"), not the name,
   because the name depends on the browser language
   ("Germany", "Deutschland", "Almanya"...).
--------------------------------------------------------- */
function detectCountry() {
  return new Promise((resolve) => {
    const fallback = "Germany";
    if (!navigator.geolocation) {
      resolve(fallback);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const json = await res.json();
          const code = (json.address && json.address.country_code || "").toUpperCase();
          const country = Object.keys(COUNTRY_MARKETS).find(c => COUNTRY_MARKETS[c].code === code);
          resolve(country || fallback);
        } catch (err) {
          console.warn("Reverse geocoding failed, using fallback country", err);
          resolve(fallback);
        }
      },
      () => resolve(fallback),
      { timeout: 5000 }
    );
  });
}

/* ---------------------------------------------------------
   7) LOCAL "DATABASE" (localStorage) - portfolio, user, cart
--------------------------------------------------------- */
const DB = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch { return fallback; }
  },
  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }
};
