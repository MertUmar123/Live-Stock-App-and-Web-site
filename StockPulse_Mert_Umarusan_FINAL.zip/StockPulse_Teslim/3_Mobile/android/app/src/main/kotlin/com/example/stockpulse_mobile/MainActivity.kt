package com.example.stockpulse_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
