// All settings you may need to change are in this one file.

// Marketstack API key (free plan: 100 requests per month, end-of-day data).
const String marketstackApiKey = "PASTE_YOUR_KEY_HERE";

// Address of the published StockPulse website (opened from the stock detail page).
const String webAppBaseUrl = "https://stockpulse-mert.free.nf";
