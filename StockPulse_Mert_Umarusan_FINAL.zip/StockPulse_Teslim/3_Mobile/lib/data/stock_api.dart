import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config.dart';
import '../models/stock.dart';

/// Gets real stock prices from the Marketstack API.
/// The free plan only allows 100 requests per month, so every answer
/// is saved on the phone (shared_preferences) and reused for 12 hours.

const String _baseUrl = "https://api.marketstack.com/v2";
const Duration _cacheTime = Duration(hours: 12);

final Map<String, MarketInfo> countryMarkets = {
  "Germany": const MarketInfo(code: "DE", flag: "🇩🇪", index: "DAX", currency: "EUR"),
  "United States": const MarketInfo(code: "US", flag: "🇺🇸", index: "S&P 500", currency: "USD"),
  "United Kingdom": const MarketInfo(code: "GB", flag: "🇬🇧", index: "FTSE 100", currency: "GBP"),
  "France": const MarketInfo(code: "FR", flag: "🇫🇷", index: "CAC 40", currency: "EUR"),
  "Japan": const MarketInfo(code: "JP", flag: "🇯🇵", index: "Nikkei 225", currency: "JPY"),
  "Turkey": const MarketInfo(code: "TR", flag: "🇹🇷", index: "BIST 100", currency: "TRY"),
};

// The free Marketstack plan does not include the German, UK, Japanese or Turkish
// exchanges, so for those companies we use their US listing (NYSE / Nasdaq, in USD).
// Paris (XPAR) works for LVMH (EUR); the other French companies use their US listing.
final Map<String, List<Stock>> stocksByCountry = {
  "Germany": const [
    Stock(symbol: "SAP", apiSymbol: "SAP", name: "SAP SE", currency: "USD", base: 224.29),
    Stock(symbol: "DB", apiSymbol: "DB", name: "Deutsche Bank", currency: "USD", base: 30.10),
    Stock(symbol: "BNTX", apiSymbol: "BNTX", name: "BioNTech SE", currency: "USD", base: 105.00),
    Stock(symbol: "FMS", apiSymbol: "FMS", name: "Fresenius Medical Care", currency: "USD", base: 24.50),
  ],
  "United States": const [
    Stock(symbol: "AAPL", apiSymbol: "AAPL", name: "Apple Inc.", currency: "USD", base: 343.46),
    Stock(symbol: "TSLA", apiSymbol: "TSLA", name: "Tesla Inc.", currency: "USD", base: 239.43),
    Stock(symbol: "NFLX", apiSymbol: "NFLX", name: "Netflix Inc.", currency: "USD", base: 855.86),
    Stock(symbol: "MSFT", apiSymbol: "MSFT", name: "Microsoft Corp.", currency: "USD", base: 421.10),
    Stock(symbol: "NVDA", apiSymbol: "NVDA", name: "NVIDIA Corp.", currency: "USD", base: 132.75),
  ],
  "United Kingdom": const [
    Stock(symbol: "HSBC", apiSymbol: "HSBC", name: "HSBC Holdings", currency: "USD", base: 94.57),
    Stock(symbol: "BP", apiSymbol: "BP", name: "BP plc", currency: "USD", base: 50.21),
    Stock(symbol: "UL", apiSymbol: "UL", name: "Unilever", currency: "USD", base: 60.00),
    Stock(symbol: "AZN", apiSymbol: "AZN", name: "AstraZeneca", currency: "USD", base: 75.00),
  ],
  "France": const [
    Stock(symbol: "MC", apiSymbol: "MC.XPAR", name: "LVMH", currency: "EUR", base: 397.00),
    Stock(symbol: "TTE", apiSymbol: "TTE", name: "TotalEnergies", currency: "USD", base: 62.10),
    Stock(symbol: "SNY", apiSymbol: "SNY", name: "Sanofi", currency: "USD", base: 50.00),
  ],
  "Japan": const [
    Stock(symbol: "TM", apiSymbol: "TM", name: "Toyota Motor", currency: "USD", base: 194.61),
    Stock(symbol: "SONY", apiSymbol: "SONY", name: "Sony Group", currency: "USD", base: 24.88),
    Stock(symbol: "MUFG", apiSymbol: "MUFG", name: "Mitsubishi UFJ Financial", currency: "USD", base: 14.00),
  ],
  "Turkey": const [
    Stock(symbol: "TKC", apiSymbol: "TKC", name: "Turkcell", currency: "USD", base: 4.93),
  ],
};

// Exchange codes (MIC) from the API -> readable names
const Map<String, String> exchangeNames = {"XNYS": "NYSE", "XNAS": "Nasdaq", "XPAR": "Euronext Paris"};

Stock? findStock(String country, String symbol) {
  for (final s in stocksByCountry[country] ?? const <Stock>[]) {
    if (s.symbol == symbol) return s;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Download with a 12-hour cache on the phone
// ---------------------------------------------------------------------------
Future<List<dynamic>?> _getWithCache(String url, String cacheKey) async {
  final prefs = await SharedPreferences.getInstance();
  final saved = prefs.getString(cacheKey);
  final savedAt = prefs.getInt('${cacheKey}_time') ?? 0;
  final age = DateTime.now().millisecondsSinceEpoch - savedAt;

  if (saved != null && age < _cacheTime.inMilliseconds) {
    return jsonDecode(saved) as List<dynamic>;
  }

  try {
    final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
    if (res.statusCode == 200) {
      final json = jsonDecode(res.body);
      if (json is Map && json['data'] is List) {
        await prefs.setString(cacheKey, jsonEncode(json['data']));
        await prefs.setInt('${cacheKey}_time', DateTime.now().millisecondsSinceEpoch);
        return json['data'] as List<dynamic>;
      }
    }
  } catch (_) {}

  // Network failed: an old saved answer is better than nothing
  if (saved != null) return jsonDecode(saved) as List<dynamic>;
  return null;
}

// Marketstack may answer "SAP.XETRA" or just "SAP", so we accept both
bool _matches(Map row, Stock s) {
  final sym = row['symbol'].toString();
  return sym == s.apiSymbol || sym == s.symbol || sym.split('.').first == s.symbol;
}

double _num(dynamic v, double fallback) => v is num ? v.toDouble() : fallback;

// ---------------------------------------------------------------------------
// Latest prices for all stocks of one country (1 API request)
// ---------------------------------------------------------------------------
Future<List<Quote>> fetchQuotes(String country) async {
  final list = stocksByCountry[country] ?? stocksByCountry["Germany"]!;
  final symbols = list.map((s) => s.apiSymbol).join(",");
  final rows = await _getWithCache(
    "$_baseUrl/eod/latest?access_key=$marketstackApiKey&symbols=$symbols",
    "latest_$symbols",
  );

  if (rows != null) {
    final quotes = <Quote>[];
    for (final s in list) {
      Map? row;
      for (final r in rows) {
        if (r is Map && _matches(r, s)) {
          row = r;
          break;
        }
      }
      if (row == null || row['close'] is! num) continue; // API has no data for this stock
      final close = _num(row['close'], 0);
      final open = _num(row['open'], close);
      quotes.add(Quote(
        symbol: s.symbol,
        name: s.name,
        currency: row['price_currency']?.toString() ?? s.currency,
        exchange: exchangeNames[row['exchange']] ?? row['exchange']?.toString() ?? "-",
        price: close,
        open: open,
        high: _num(row['high'], close),
        low: _num(row['low'], close),
        volume: _num(row['volume'], 0),
        date: row['date'].toString().split('T').first,
        change: double.parse((close - open).toStringAsFixed(2)),
        changePct: open == 0 ? 0 : double.parse((((close - open) / open) * 100).toStringAsFixed(2)),
      ));
    }
    if (quotes.isNotEmpty) return quotes;
  }

  return list.map(sampleQuote).toList();
}

// ---------------------------------------------------------------------------
// Daily closing prices of the last year for one stock (1 API request).
// The 1D / 1M / 3M / 1Y ranges are all cut from this one answer.
// ---------------------------------------------------------------------------
Future<PriceHistory> fetchHistory(Stock s) async {
  final from = DateTime.now().subtract(const Duration(days: 365)).toIso8601String().split('T').first;
  final rows = await _getWithCache(
    "$_baseUrl/eod?access_key=$marketstackApiKey&symbols=${s.apiSymbol}&date_from=$from&limit=300",
    "history_${s.apiSymbol}",
  );

  if (rows != null) {
    final points = <PricePoint>[];
    for (final r in rows) {
      if (r is Map && r['close'] is num) {
        points.add(PricePoint(r['date'].toString().split('T').first, (r['close'] as num).toDouble()));
      }
    }
    points.sort((a, b) => a.date.compareTo(b.date)); // oldest first
    if (points.isNotEmpty) return PriceHistory(points);
  }

  return PriceHistory(_sampleHistory(s), isSample: true);
}

// Trading days per range. The free plan has no intraday data,
// so "1D" shows the last 5 trading days.
const Map<String, int> rangeDays = {"1D": 5, "1M": 22, "3M": 66, "1Y": 252};

List<PricePoint> cutRange(List<PricePoint> points, String range) {
  final n = rangeDays[range] ?? 22;
  return points.length <= n ? points : points.sublist(points.length - n);
}

// ---------------------------------------------------------------------------
// Sample data - ONLY used when the API cannot be reached.
// It is marked with isSample, and the app shows a warning.
// ---------------------------------------------------------------------------
double _seededRandom(num seed) {
  final x = sin(seed) * 10000;
  return x - x.floor();
}

Quote sampleQuote(Stock s) {
  final changePct = (_seededRandom(s.symbol.codeUnitAt(0) + s.symbol.length) - 0.5) * 8;
  final price = s.base * (1 + changePct / 100);
  return Quote(
    symbol: s.symbol,
    name: s.name,
    currency: s.currency,
    exchange: "-",
    price: double.parse(price.toStringAsFixed(2)),
    open: s.base,
    high: max(price, s.base),
    low: min(price, s.base),
    volume: 0,
    date: "-",
    change: double.parse((price - s.base).toStringAsFixed(2)),
    changePct: double.parse(changePct.toStringAsFixed(2)),
    isSample: true,
  );
}

List<PricePoint> _sampleHistory(Stock s) {
  final points = <PricePoint>[];
  double value = s.base;
  var day = DateTime.now();
  for (int i = 0; i < 252; i++) {
    final drift = (_seededRandom(s.symbol.codeUnitAt(0) * (i + 1)) - 0.48) * (s.base * 0.015);
    value = max(value + drift, s.base * 0.5);
    points.insert(0, PricePoint(day.toIso8601String().split('T').first, double.parse(value.toStringAsFixed(2))));
    day = day.subtract(const Duration(days: 1));
  }
  return points;
}
