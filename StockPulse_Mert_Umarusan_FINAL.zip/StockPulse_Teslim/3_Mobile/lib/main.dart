import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/markets_screen.dart';
import 'screens/portfolio_screen.dart';
import 'screens/pro_screen.dart';
import 'screens/auth_screen.dart';

void main() {
  runApp(const StockPulseApp());
}

// Shared app state (very light — no external state package needed for this project)
class AppState {
  static String country = "Germany";
  static String currency = "EUR";
}

const Color kBg = Color(0xFF0A0E13);
const Color kSurface = Color(0xFF12171F);
const Color kSurfaceAlt = Color(0xFF1A212B);
const Color kBorder = Color(0xFF232B37);
const Color kAccent = Color(0xFF00D9B5);
const Color kUp = Color(0xFF1FCE8F);
const Color kDown = Color(0xFFF0475A);
const Color kTextDim = Color(0xFF8B96A7);

class StockPulseApp extends StatelessWidget {
  const StockPulseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StockPulse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kAccent,
          brightness: Brightness.dark,
          primary: kAccent,
          surface: kSurface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kBg,
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        cardColor: kSurface,
        fontFamily: 'Roboto',
      ),
      home: const RootNav(),
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> {
  int _index = 0;

  final _pages = const [
    HomeScreen(),
    MarketsScreen(),
    PortfolioScreen(),
    ProScreen(),
    AuthScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: kSurface,
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: "Home"),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: "Markets"),
          NavigationDestination(icon: Icon(Icons.pie_chart_outline), selectedIcon: Icon(Icons.pie_chart), label: "Portfolio"),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: "Pro"),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: "Account"),
        ],
      ),
    );
  }
}
