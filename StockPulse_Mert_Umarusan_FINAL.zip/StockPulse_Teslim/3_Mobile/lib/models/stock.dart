class Stock {
  final String symbol; // what we show, e.g. "SAP"
  final String apiSymbol; // what Marketstack expects, e.g. "SAP.XETRA"
  final String name;
  final String currency; // currency the API returns the price in
  final double base; // typical price, only used for sample data when offline

  const Stock({required this.symbol, required this.apiSymbol, required this.name, required this.currency, required this.base});
}

class Quote {
  final String symbol;
  final String name;
  final String currency;
  final String exchange;
  final double price; // closing price of the last trading day
  final double open;
  final double high;
  final double low;
  final double volume;
  final String date;
  final double change;
  final double changePct;
  final bool isSample; // true = API was offline, numbers are not real

  const Quote({
    required this.symbol,
    required this.name,
    required this.currency,
    required this.exchange,
    required this.price,
    required this.open,
    required this.high,
    required this.low,
    required this.volume,
    required this.date,
    required this.change,
    required this.changePct,
    this.isSample = false,
  });

  bool get isUp => changePct >= 0;
}

class PricePoint {
  final String date;
  final double close;
  const PricePoint(this.date, this.close);
}

class PriceHistory {
  final List<PricePoint> points; // oldest first
  final bool isSample;
  const PriceHistory(this.points, {this.isSample = false});
}

class MarketInfo {
  final String code; // ISO country code from the Geolocator, e.g. "DE"
  final String flag;
  final String index;
  final String currency;

  const MarketInfo({required this.code, required this.flag, required this.index, required this.currency});
}
