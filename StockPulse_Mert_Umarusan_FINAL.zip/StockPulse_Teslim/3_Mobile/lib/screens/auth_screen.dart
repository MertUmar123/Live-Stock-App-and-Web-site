import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isSignIn = true;
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  String? _message;
  String? _signedInAs;

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _signedInAs = prefs.getString('spx_user_email'));
  }

  Future<void> _submit() async {
    if (_emailCtrl.text.isEmpty || _passCtrl.text.isEmpty) {
      setState(() => _message = "Please fill in all fields.");
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('spx_user_email', _emailCtrl.text);
    setState(() {
      _signedInAs = _emailCtrl.text;
      _message = _isSignIn ? "Signed in successfully." : "Account created — you're signed in.";
    });
  }

  Future<void> _signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('spx_user_email');
    setState(() {
      _signedInAs = null;
      _message = null;
      _emailCtrl.clear();
      _passCtrl.clear();
      _nameCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text("Account")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _signedInAs != null ? _signedInView() : _formView(),
      ),
    );
  }

  Widget _signedInView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const CircleAvatar(radius: 34, backgroundColor: kSurfaceAlt, child: Icon(Icons.person, color: kAccent, size: 34)),
        const SizedBox(height: 14),
        Text("Signed in as", style: const TextStyle(color: kTextDim)),
        Text(_signedInAs!, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 24),
        OutlinedButton(
          onPressed: _signOut,
          style: OutlinedButton.styleFrom(side: const BorderSide(color: kBorder)),
          child: const Text("Sign out", style: TextStyle(color: kDown)),
        ),
      ],
    );
  }

  Widget _formView() {
    return ListView(
      children: [
        Row(
          children: [
            Expanded(
              child: _tabButton("Sign in", _isSignIn, () => setState(() => _isSignIn = true)),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _tabButton("Register", !_isSignIn, () => setState(() => _isSignIn = false)),
            ),
          ],
        ),
        const SizedBox(height: 20),
        if (!_isSignIn) ...[
          _field("Full name", _nameCtrl),
          const SizedBox(height: 12),
        ],
        _field("Email", _emailCtrl),
        const SizedBox(height: 12),
        _field("Password", _passCtrl, obscure: true),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(
            backgroundColor: kAccent,
            foregroundColor: const Color(0xFF06110D),
            minimumSize: const Size(double.infinity, 48),
          ),
          child: Text(_isSignIn ? "Sign in" : "Create account"),
        ),
        if (_message != null) ...[
          const SizedBox(height: 12),
          Text(_message!, style: const TextStyle(color: kTextDim), textAlign: TextAlign.center),
        ]
      ],
    );
  }

  Widget _tabButton(String label, bool active, VoidCallback onTap) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        backgroundColor: active ? kAccent.withOpacity(0.15) : Colors.transparent,
        side: BorderSide(color: active ? kAccent : kBorder),
      ),
      child: Text(label, style: TextStyle(color: active ? kAccent : kTextDim)),
    );
  }

  Widget _field(String label, TextEditingController ctrl, {bool obscure = false}) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: kTextDim),
        filled: true,
        fillColor: kSurfaceAlt,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kAccent)),
      ),
    );
  }
}
