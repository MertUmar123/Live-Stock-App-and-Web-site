import 'package:flutter/material.dart';
import '../main.dart';
import '../data/stock_api.dart';
import '../services/location_service.dart';
import '../models/stock.dart';
import '../widgets/sample_notice.dart';
import 'markets_screen.dart';
import 'stock_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _loading = true;
  String _country = AppState.country;
  List<Quote> _quotes = [];
  String _locationMessage = "Detecting location…";
  bool _locationOk = false;

  @override
  void initState() {
    super.initState();
    _detectAndLoad();
  }

  // 1) Ask the Geolocator for the country, 2) load that country's stocks
  Future<void> _detectAndLoad() async {
    setState(() => _loading = true);
    final result = await LocationService.detectCountry();
    if (!mounted) return;
    setState(() {
      _locationMessage = result.message;
      _locationOk = result.detected;
    });
    await _loadCountry(result.country);
  }

  // Also used when the user picks a country by hand
  Future<void> _loadCountry(String country) async {
    setState(() {
      _loading = true;
      _country = country;
    });
    AppState.country = country;
    AppState.currency = countryMarkets[country]!.currency;
    final quotes = await fetchQuotes(country);
    if (!mounted) return;
    setState(() {
      _quotes = quotes;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final market = countryMarkets[_country]!;
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text("StockPulse")),
      body: RefreshIndicator(
        onRefresh: _detectAndLoad,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Rotation-safe asset image - AspectRatio + FittedBox prevents overflow
            AspectRatio(
              aspectRatio: 16 / 7,
              child: FittedBox(
                fit: BoxFit.cover,
                child: Image.asset('assets/icon/app_icon.png', width: 400, height: 175),
              ),
            ),
            const SizedBox(height: 18),
            const Text("Look first. Then leap.",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: Colors.white)),
            const SizedBox(height: 6),
            const Text("Your market, wherever you are.", style: TextStyle(color: kTextDim, fontSize: 15)),
            const SizedBox(height: 16),

            // Country: detected automatically, but the user can change it
            DropdownButtonFormField<String>(
              value: _country,
              dropdownColor: kSurfaceAlt,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Market",
                labelStyle: const TextStyle(color: kTextDim),
                filled: true,
                fillColor: kSurface,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
              ),
              items: countryMarkets.entries
                  .map((e) => DropdownMenuItem(value: e.key, child: Text("${e.value.flag} ${e.key} · ${e.value.index}")))
                  .toList(),
              onChanged: _loading
                  ? null
                  : (c) {
                      setState(() {
                        _locationMessage = "Chosen by you";
                        _locationOk = true;
                      });
                      _loadCountry(c!);
                    },
            ),
            const SizedBox(height: 6),
            // Shows where the country came from (GPS, user choice, or why GPS failed)
            Row(
              children: [
                Icon(_locationOk ? Icons.location_on : Icons.location_off,
                    size: 14, color: _locationOk ? kAccent : kTextDim),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    _locationOk ? _locationMessage : "$_locationMessage - showing $_country",
                    style: const TextStyle(color: kTextDim, fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Today's market · ${market.index}",
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                TextButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const MarketsScreen()),
                  ),
                  child: const Text("View all →"),
                )
              ],
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Center(child: CircularProgressIndicator(color: kAccent)),
              )
            else ...[
              if (_quotes.isNotEmpty && _quotes.first.isSample) const SampleNotice(),
              if (_quotes.isNotEmpty && !_quotes.first.isSample)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text("Last trading day: ${_quotes.first.date}",
                      style: const TextStyle(color: kTextDim, fontSize: 12)),
                ),
              ..._quotes.take(4).map((q) => GestureDetector(
                    onTap: () {
                      final stock = findStock(_country, q.symbol);
                      if (stock == null) return;
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => StockDetailScreen(stock: stock)));
                    },
                    child: _QuoteTile(quote: q),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}

class _QuoteTile extends StatelessWidget {
  final Quote quote;
  const _QuoteTile({required this.quote});

  @override
  Widget build(BuildContext context) {
    final up = quote.isUp;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: (up ? kUp : kDown).withOpacity(0.5)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(quote.symbol, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              Text(quote.name, style: const TextStyle(color: kTextDim, fontSize: 12)),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text("${quote.price.toStringAsFixed(2)} ${quote.currency}",
                  style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.w600)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: (up ? kUp : kDown).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  "${up ? '▲' : '▼'} ${quote.changePct.abs().toStringAsFixed(2)}%",
                  style: TextStyle(color: up ? kUp : kDown, fontSize: 12, fontFamily: 'monospace'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
