import 'package:flutter/material.dart';
import '../main.dart';
import '../data/stock_api.dart';
import '../models/stock.dart';
import '../services/links.dart';
import '../widgets/sample_notice.dart';
import 'stock_detail_screen.dart';

class MarketsScreen extends StatefulWidget {
  const MarketsScreen({super.key});
  @override
  State<MarketsScreen> createState() => _MarketsScreenState();
}

class _MarketsScreenState extends State<MarketsScreen> {
  bool _loading = true;
  List<Quote> _quotes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final quotes = await fetchQuotes(AppState.country);
    if (!mounted) return;
    setState(() {
      _quotes = quotes;
      _loading = false;
    });
  }

  // News topics for the current country; each one opens live headlines on Google News
  List<Map<String, String>> get _news {
    final m = countryMarkets[AppState.country]!;
    return [
      {"tag": "Markets", "title": "${m.index} today: latest market moves", "query": "${m.index} stock market"},
      {"tag": "Economy", "title": "${AppState.country} economy news", "query": "${AppState.country} economy"},
      {"tag": "Tech", "title": "Tech stocks and earnings", "query": "tech stocks earnings"},
      {"tag": "Energy", "title": "Oil prices and energy stocks", "query": "oil prices energy stocks"},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text("News & Markets")),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text("Stock prices", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text("Tap a stock for full details", style: TextStyle(color: kTextDim, fontSize: 12)),
            const SizedBox(height: 10),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 30),
                child: Center(child: CircularProgressIndicator(color: kAccent)),
              )
            else ...[
              if (_quotes.isNotEmpty && _quotes.first.isSample) const SampleNotice(),
              ..._quotes.map((q) => GestureDetector(
                    onTap: () {
                      final stock = findStock(AppState.country, q.symbol);
                      if (stock == null) return;
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => StockDetailScreen(stock: stock),
                      ));
                    },
                    child: _QuoteRow(quote: q),
                  )),
            ],
            const SizedBox(height: 26),
            const Text("Market news", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            ..._news.map((n) => GestureDetector(
                  onTap: () => openLink(context, newsUrl(n["query"]!)),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: kBorder),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: kSurfaceAlt, borderRadius: BorderRadius.circular(5)),
                                child: Text(n["tag"]!, style: const TextStyle(color: kTextDim, fontSize: 10)),
                              ),
                              const SizedBox(height: 6),
                              Text(n["title"]!, style: const TextStyle(color: Colors.white, fontSize: 14)),
                            ],
                          ),
                        ),
                        const Icon(Icons.open_in_new, color: kTextDim, size: 18),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class _QuoteRow extends StatelessWidget {
  final Quote quote;
  const _QuoteRow({required this.quote});

  @override
  Widget build(BuildContext context) {
    final up = quote.isUp;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(quote.symbol, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                Text(quote.name, style: const TextStyle(color: kTextDim, fontSize: 11), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          Row(
            children: [
              Text("${quote.price.toStringAsFixed(2)} ${quote.currency}", style: const TextStyle(color: Colors.white, fontFamily: 'monospace')),
              const SizedBox(width: 8),
              Icon(up ? Icons.arrow_drop_up : Icons.arrow_drop_down, color: up ? kUp : kDown),
              Text("${quote.changePct.abs().toStringAsFixed(2)}%", style: TextStyle(color: up ? kUp : kDown, fontSize: 12)),
              const Icon(Icons.chevron_right, color: kTextDim, size: 18),
            ],
          ),
        ],
      ),
    );
  }
}
