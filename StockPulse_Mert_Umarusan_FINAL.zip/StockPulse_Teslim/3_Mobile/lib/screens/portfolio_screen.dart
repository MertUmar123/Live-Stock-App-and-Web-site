import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';
import '../data/stock_api.dart';
import '../models/stock.dart';

class Holding {
  final String symbol;
  final String country;
  int shares;
  Holding({required this.symbol, required this.country, required this.shares});

  Map<String, dynamic> toJson() => {"symbol": symbol, "country": country, "shares": shares};
  factory Holding.fromJson(Map<String, dynamic> j) =>
      Holding(symbol: j["symbol"], country: j["country"], shares: j["shares"]);
}

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({super.key});
  @override
  State<PortfolioScreen> createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends State<PortfolioScreen> {
  List<Holding> _holdings = [];
  Map<String, Quote> _quoteMap = {};
  bool _loading = true;
  String _addCountry = "Germany";
  String _addSymbol = "";
  int _addShares = 10;

  @override
  void initState() {
    super.initState();
    _addCountry = AppState.country;
    _addSymbol = stocksByCountry[_addCountry]!.first.symbol;
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('spx_portfolio');
    final holdings = raw == null
        ? <Holding>[]
        : (jsonDecode(raw) as List).map((e) => Holding.fromJson(e)).toList();

    final Map<String, Quote> qMap = {};
    for (final country in {for (final h in holdings) h.country}) {
      final quotes = await fetchQuotes(country);
      for (final q in quotes) {
        qMap["${country}_${q.symbol}"] = q;
      }
    }

    setState(() {
      _holdings = holdings;
      _quoteMap = qMap;
      _loading = false;
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('spx_portfolio', jsonEncode(_holdings.map((h) => h.toJson()).toList()));
  }

  Future<void> _addHolding() async {
    final existing = _holdings.where((h) => h.symbol == _addSymbol && h.country == _addCountry);
    if (existing.isNotEmpty) {
      existing.first.shares += _addShares;
    } else {
      _holdings.add(Holding(symbol: _addSymbol, country: _addCountry, shares: _addShares));
    }
    await _save();
    await _load();
  }

  Future<void> _removeHolding(Holding h) async {
    _holdings.removeWhere((x) => x.symbol == h.symbol && x.country == h.country);
    await _save();
    await _load();
  }

  double get _total {
    double sum = 0;
    for (final h in _holdings) {
      final q = _quoteMap["${h.country}_${h.symbol}"];
      if (q != null) sum += q.price * h.shares;
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text("Portfolio")),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kAccent))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: kSurface, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Total portfolio value", style: TextStyle(color: kTextDim, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(_total.toStringAsFixed(2), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700, fontFamily: 'monospace')),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text("Holdings", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                if (_holdings.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text("No holdings yet — add one below.", style: TextStyle(color: kTextDim)),
                  )
                else
                  ..._holdings.map((h) {
                    final q = _quoteMap["${h.country}_${h.symbol}"];
                    final up = q?.isUp ?? true;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: kSurface, borderRadius: BorderRadius.circular(10), border: Border.all(color: kBorder)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(h.symbol, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                              Text("${h.shares} shares", style: const TextStyle(color: kTextDim, fontSize: 12)),
                            ],
                          ),
                          Row(
                            children: [
                              if (q != null)
                                Text("${(q.price * h.shares).toStringAsFixed(2)}",
                                    style: TextStyle(color: up ? kUp : kDown, fontFamily: 'monospace')),
                              IconButton(
                                icon: const Icon(Icons.close, color: kTextDim, size: 18),
                                onPressed: () => _removeHolding(h),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }),
                const SizedBox(height: 24),
                const Text("Add to portfolio", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: _addCountry,
                  dropdownColor: kSurfaceAlt,
                  decoration: _dropdownDecoration("Country"),
                  style: const TextStyle(color: Colors.white),
                  items: countryMarkets.keys.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setState(() {
                    _addCountry = v!;
                    _addSymbol = stocksByCountry[_addCountry]!.first.symbol;
                  }),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: _addSymbol,
                  dropdownColor: kSurfaceAlt,
                  decoration: _dropdownDecoration("Stock"),
                  style: const TextStyle(color: Colors.white),
                  items: stocksByCountry[_addCountry]!
                      .map((s) => DropdownMenuItem(value: s.symbol, child: Text("${s.symbol} — ${s.name}")))
                      .toList(),
                  onChanged: (v) => setState(() => _addSymbol = v!),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  initialValue: "10",
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white),
                  decoration: _dropdownDecoration("Shares"),
                  onChanged: (v) => _addShares = int.tryParse(v) ?? 1,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _addHolding,
                  style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: const Color(0xFF06110D), minimumSize: const Size(double.infinity, 48)),
                  child: const Text("Add holding"),
                ),
              ],
            ),
    );
  }

  InputDecoration _dropdownDecoration(String label) => InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: kTextDim),
        filled: true,
        fillColor: kSurfaceAlt,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kBorder)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: kAccent)),
      );
}
