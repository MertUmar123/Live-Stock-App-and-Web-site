import 'package:flutter/material.dart';
import '../main.dart';

class ProScreen extends StatefulWidget {
  const ProScreen({super.key});
  @override
  State<ProScreen> createState() => _ProScreenState();
}

class _ProScreenState extends State<ProScreen> {
  String? _selectedPlan;
  bool _purchased = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text("Go Pro")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Upgrade to StockPulse Pro",
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text("Real-time alerts, unlimited watchlists, and deeper analytics.",
              style: TextStyle(color: kTextDim)),
          const SizedBox(height: 22),
          _planCard(
            title: "Pro",
            price: "\$9.99/mo",
            features: const ["All global markets", "Real-time alerts", "Unlimited watchlists"],
            highlighted: true,
          ),
          const SizedBox(height: 14),
          _planCard(
            title: "Team",
            price: "\$24.99/mo",
            features: const ["Everything in Pro", "Up to 5 seats", "Shared watchlists"],
            highlighted: false,
          ),
          const SizedBox(height: 24),
          if (_selectedPlan != null && !_purchased)
            ElevatedButton(
              onPressed: () => setState(() => _purchased = true),
              style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: const Color(0xFF06110D), minimumSize: const Size(double.infinity, 48)),
              child: Text("Confirm $_selectedPlan plan"),
            ),
          if (_purchased)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: kUp.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: kUp)),
              child: Text("You're now on the $_selectedPlan plan. Welcome to Pro!", style: const TextStyle(color: kUp)),
            ),
        ],
      ),
    );
  }

  Widget _planCard({required String title, required String price, required List<String> features, required bool highlighted}) {
    final selected = _selectedPlan == title;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: selected ? kAccent : (highlighted ? kAccent.withOpacity(0.4) : kBorder), width: selected ? 2 : 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: kAccent, fontFamily: 'monospace', fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 6),
          Text(price, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w700, fontFamily: 'monospace')),
          const SizedBox(height: 10),
          ...features.map((f) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(children: [
                  const Icon(Icons.check, color: kAccent, size: 16),
                  const SizedBox(width: 6),
                  Text(f, style: const TextStyle(color: kTextDim)),
                ]),
              )),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => setState(() {
                _selectedPlan = title;
                _purchased = false;
              }),
              style: OutlinedButton.styleFrom(side: BorderSide(color: selected ? kAccent : kBorder)),
              child: Text(selected ? "Selected" : "Choose $title", style: TextStyle(color: selected ? kAccent : Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}
