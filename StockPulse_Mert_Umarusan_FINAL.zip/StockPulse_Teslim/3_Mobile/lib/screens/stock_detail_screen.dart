import 'dart:math';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../main.dart';
import '../config.dart';
import '../data/stock_api.dart';
import '../models/stock.dart';
import '../services/links.dart';
import '../widgets/sample_notice.dart';

class StockDetailScreen extends StatefulWidget {
  final Stock stock;
  const StockDetailScreen({super.key, required this.stock});

  @override
  State<StockDetailScreen> createState() => _StockDetailScreenState();
}

class _StockDetailScreenState extends State<StockDetailScreen> {
  String _range = "1D";
  bool _loading = true;
  late Quote _quote;
  late PriceHistory _history;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // Load the latest price and the one-year history once.
  // Changing the range (1D/1M/3M/1Y) only cuts the history, no new request.
  Future<void> _load() async {
    final quotes = await fetchQuotes(AppState.country);
    Quote quote = sampleQuote(widget.stock);
    for (final q in quotes) {
      if (q.symbol == widget.stock.symbol) quote = q;
    }
    final history = await fetchHistory(widget.stock);
    if (!mounted) return;
    setState(() {
      _quote = quote;
      _history = history;
      _loading = false;
    });
  }

  String _volume(double v) {
    if (v <= 0) return "-";
    if (v >= 1e9) return "${(v / 1e9).toStringAsFixed(2)}B";
    if (v >= 1e6) return "${(v / 1e6).toStringAsFixed(2)}M";
    if (v >= 1e3) return "${(v / 1e3).toStringAsFixed(1)}K";
    return v.toStringAsFixed(0);
  }

  @override
  Widget build(BuildContext context) {
    final market = countryMarkets[AppState.country]!;
    final s = widget.stock;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: Text(s.symbol)),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kAccent))
          : _content(market, s),
    );
  }

  Widget _content(MarketInfo market, Stock s) {
    final up = _quote.isUp;
    final points = cutRange(_history.points, _range);
    final chartUp = points.last.close >= points.first.close;
    final closes = _history.points.map((p) => p.close);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_quote.isSample || _history.isSample) const SampleNotice(),
        Text(s.name, style: const TextStyle(color: kTextDim, fontSize: 14)),
        const SizedBox(height: 4),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text("${_quote.price.toStringAsFixed(2)} ${_quote.currency}",
                style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700, fontFamily: 'monospace')),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              margin: const EdgeInsets.only(bottom: 6),
              decoration: BoxDecoration(color: (up ? kUp : kDown).withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
              child: Text("${up ? '▲' : '▼'} ${_quote.changePct.abs().toStringAsFixed(2)}%",
                  style: TextStyle(color: up ? kUp : kDown, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        const SizedBox(height: 18),

        // Range buttons
        Wrap(
          spacing: 8,
          children: rangeDays.keys.map((r) {
            final selected = r == _range;
            return ChoiceChip(
              label: Text(r),
              selected: selected,
              onSelected: (_) => setState(() => _range = r),
              selectedColor: kAccent.withOpacity(0.18),
              backgroundColor: kSurface,
              labelStyle: TextStyle(color: selected ? kAccent : kTextDim, fontFamily: 'monospace'),
              side: BorderSide(color: selected ? kAccent : kBorder),
            );
          }).toList(),
        ),
        const SizedBox(height: 16),

        // Chart (fl_chart package): green if the period went up, red if down
        SizedBox(
          height: 200,
          child: LineChart(
            LineChartData(
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                getDrawingHorizontalLine: (v) => FlLine(color: kBorder, strokeWidth: 1),
              ),
              titlesData: const FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
              lineBarsData: [
                LineChartBarData(
                  spots: [for (int i = 0; i < points.length; i++) FlSpot(i.toDouble(), points[i].close)],
                  isCurved: true,
                  color: chartUp ? kUp : kDown,
                  barWidth: 2.5,
                  dotData: FlDotData(show: _range == "1D"),
                  belowBarData: BarAreaData(show: true, color: (chartUp ? kUp : kDown).withOpacity(0.12)),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          _range == "1D"
              ? "Free API plan has no intraday data, so 1D shows the last 5 trading days."
              : "${points.first.date} → ${points.last.date}",
          style: const TextStyle(color: kTextDim, fontSize: 11),
        ),
        const SizedBox(height: 22),

        // Key information table
        const Text("Key information", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Table(
          columnWidths: const {0: FlexColumnWidth(1), 1: FlexColumnWidth(1)},
          children: [
            _row("Trading day", _quote.date),
            _row("Open", _quote.open.toStringAsFixed(2)),
            _row("High", _quote.high.toStringAsFixed(2)),
            _row("Low", _quote.low.toStringAsFixed(2)),
            _row("Close", _quote.price.toStringAsFixed(2)),
            _row("Volume", _volume(_quote.volume)),
            _row("52-week high", closes.reduce(max).toStringAsFixed(2)),
            _row("52-week low", closes.reduce(min).toStringAsFixed(2)),
            _row("Currency", _quote.currency),
            _row("Listed on", _quote.exchange),
            _row("Home market", market.index),
          ],
        ),
        const SizedBox(height: 22),

        // Links to news
        const Text("News", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        _newsLink("Latest news about ${s.name}", "${s.name} stock"),
        _newsLink("${s.name} earnings and analyst ratings", "${s.name} earnings analysts"),
        const SizedBox(height: 16),

        // Open the same stock on the website for bigger charts
        OutlinedButton.icon(
          onPressed: () => openLink(
            context,
            "$webAppBaseUrl/stock-detail.html?symbol=${s.symbol}&country=${Uri.encodeComponent(AppState.country)}",
          ),
          icon: const Icon(Icons.open_in_new, color: kAccent),
          label: const Text("View detailed charts on web", style: TextStyle(color: kAccent)),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: kBorder),
            padding: const EdgeInsets.symmetric(vertical: 14),
            minimumSize: const Size(double.infinity, 0),
          ),
        ),
      ],
    );
  }

  TableRow _row(String label, String value) {
    return TableRow(children: [
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(label, style: const TextStyle(color: kTextDim)),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white, fontFamily: 'monospace')),
      ),
    ]);
  }

  Widget _newsLink(String title, String query) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: const Icon(Icons.article_outlined, color: kAccent),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14)),
      trailing: const Icon(Icons.open_in_new, color: kTextDim, size: 18),
      onTap: () => openLink(context, newsUrl(query)),
    );
  }
}
