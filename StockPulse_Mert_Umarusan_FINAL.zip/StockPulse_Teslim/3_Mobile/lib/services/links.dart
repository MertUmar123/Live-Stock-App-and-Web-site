import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// Google News search link for any words
String newsUrl(String query) => "https://news.google.com/search?q=${Uri.encodeComponent(query)}";

/// Opens a link in the phone's browser; shows a message if that fails
Future<void> openLink(BuildContext context, String url) async {
  bool ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Could not open the link.")),
    );
  }
}
