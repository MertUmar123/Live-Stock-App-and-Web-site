import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../data/stock_api.dart';

/// Result of the location check: which country, and a short message for the user
class LocationResult {
  final String country;
  final bool detected; // true = really found with GPS, false = fallback used
  final String message;
  const LocationResult(this.country, this.detected, this.message);
}

/// 1) The Geolocator package gets the GPS coordinates of the phone.
/// 2) OpenStreetMap (Nominatim) turns the coordinates into a country code ("FR").
///    The website uses the same service, so web and mobile work the same way.
/// We compare the country code, not the name, because the name depends on the
/// phone language ("Germany", "Deutschland", "Almanya").
/// If something fails we fall back to Germany and say why.
class LocationService {
  static const String fallback = "Germany";

  static Future<LocationResult> detectCountry() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return const LocationResult(fallback, false, "Location is turned off on this device");
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return const LocationResult(fallback, false, "Location permission was denied");
      }

      // Try a fresh position first; if that is too slow, use the last known one
      Position? position;
      try {
        position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
        ).timeout(const Duration(seconds: 10));
      } catch (_) {
        position = await Geolocator.getLastKnownPosition();
      }
      if (position == null) {
        return const LocationResult(fallback, false, "Could not get a GPS position");
      }

      // Coordinates -> country code with OpenStreetMap
      final url = Uri.parse(
        "https://nominatim.openstreetmap.org/reverse?format=json&zoom=3"
        "&lat=${position.latitude}&lon=${position.longitude}",
      );
      final res = await http
          .get(url, headers: {"User-Agent": "StockPulse student project"})
          .timeout(const Duration(seconds: 8));
      final json = jsonDecode(res.body);
      final code = (json["address"]?["country_code"] ?? "").toString().toUpperCase();

      for (final entry in countryMarkets.entries) {
        if (entry.value.code == code) {
          return LocationResult(entry.key, true, "Detected from your location");
        }
      }
      return LocationResult(fallback, false, "Your country (${code.isEmpty ? "unknown" : code}) is not in our list yet");
    } catch (e) {
      return const LocationResult(fallback, false, "Could not find your country");
    }
  }
}
