import 'package:flutter/material.dart';
import '../main.dart';

/// Red warning box, shown only when the API was offline and sample numbers are on screen
class SampleNotice extends StatelessWidget {
  const SampleNotice({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kDown.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: kDown),
      ),
      child: const Text(
        "⚠ Stock API is not reachable right now - showing sample data.",
        style: TextStyle(color: kDown, fontSize: 13),
      ),
    );
  }
}
