import 'package:flutter_test/flutter_test.dart';
import 'package:stockpulse_mobile/data/stock_api.dart';
import 'package:stockpulse_mobile/models/stock.dart';

void main() {
  test('1D range returns the last 5 trading days', () {
    final points = List.generate(30, (i) => PricePoint('day$i', i.toDouble()));
    final result = cutRange(points, '1D');
    expect(result.length, 5);
    expect(result.last.close, 29);
  });

  test('every country has at least one stock', () {
    for (final country in countryMarkets.keys) {
      expect(stocksByCountry[country], isNotEmpty);
    }
  });
}