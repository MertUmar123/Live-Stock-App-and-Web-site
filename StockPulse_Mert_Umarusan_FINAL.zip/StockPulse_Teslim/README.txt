StockPulse - Frontend Programming Retake Project
Student: Mert Umarusan

LIVE WEBSITE
  https://stockpulse-mert.free.nf

FOLDERS
  1_Figma        Figma design file (same logo and colours for web and mobile)
  2_Web          Website: HTML5, CSS3, Bootstrap 5, vanilla JavaScript, PHP, Chart.js
                 api/stocks.php = PHP backend that calls the Marketstack API and caches answers
  3_Mobile       Flutter (Dart) mobile app - the code is in lib/
  4_Widget_Tree  Widget tree of the Flutter app (6 screens)

DATA SOURCES
  Stock prices:   Marketstack API (free plan, end-of-day data)
  Currency rates: Frankfurter API (free, no key)
  Location:       Geolocator (mobile) / browser Geolocation API (web) + OpenStreetMap

API KEY
  For security, the Marketstack API key is not included in this zip.
  The live website uses its own key on the server.
  To run locally, paste a free Marketstack key into:
    2_Web/api/config.php
    3_Mobile/lib/config.dart

RUN THE MOBILE APP
  cd 3_Mobile
  flutter pub get
  flutter run
